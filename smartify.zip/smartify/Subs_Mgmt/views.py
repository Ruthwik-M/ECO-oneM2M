from django.db import IntegrityError
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.cache import cache


def format_sub_data(data, format="raw"):
        if "con" in data:

            try:
                str = data.split("<con>[")[1].split("]</con>")[0]

            except:
                resp = json.loads(data)
                str = \
                    resp["m2m:sgn"]["m2m:nev"]["m2m:rep"]["m2m:cin"]["con"].split("[")[
                        1].split("]")[0]
                _ver = \
                    resp["m2m:sgn"]["m2m:nev"]["m2m:rep"]["m2m:cin"]["lbl"]
            # print(_ver)
            strs = str.split(",")
            if format == "raw":
                return strs
            elif format == "json":
                return strs
            else:
                raise Exception("Unhandled Data Format")
                return strs


# Create your views here.
@csrf_exempt
def post_data(request, name):
    """
    Extracts the Subscription data and Stores it in Database
    @param request:
    @param name:
    @return:
    """
    body = request.body.decode(encoding='UTF-8', errors='strict')
    response = format_sub_data(body, "raw")

    try:
        try:
            cache.set(name, response , None)
            print(cache.get('OC-KH95-00'))
        except IntegrityError as e:

            pass
    except:
        raise Exception("Dynamic table Data Fact couldn't be handled")

    return JsonResponse(data={"status": "201 created"}, status=200, safe=False)
