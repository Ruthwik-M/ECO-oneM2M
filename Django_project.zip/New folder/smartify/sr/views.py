from django.shortcuts import render
from django.core.cache import cache
# Create your views here.
def default_map(request):
    data = cache.get("OC-KH95-00")
    print(data)
    return render(request, 'default.html', {})
