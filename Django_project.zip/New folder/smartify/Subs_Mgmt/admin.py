"""
Admin Page Model Registration
"""

from django.contrib import admin
