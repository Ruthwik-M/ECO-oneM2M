from django.db import IntegrityError
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from Handler.request_handler import request_handler
from .models import Data_Fact, Vertical
from django.core.cache import cache
import json
from Handler.sendOffCmd import runs as off
from Handler.sendOnCmd import runs as on

# Create your views here.
@csrf_exempt
def post_data(request, name):
    """
    Extracts the Subscription data and Stores it in Database
    @param request:
    @param name:
    @return:
    """
    body = request.body.decode(encoding='UTF-8', errors='strict')


    if name == "OC-KH95-04":
        if "Override ON" in str(body):
            on()
            pass
        elif "Override OFF" in str(body):
            off()
            pass

    #var = request_handler(name).handle_sub_request()
    #_db = var._cw.get_vert_id()
    #body = request.body.decode(encoding='UTF-8', errors='strict')
    #response = var.format_sub_data(body, "raw")
    else:
        response = format_sub_data(body, "raw")
        cache.set(name, response[3].replace(" ",  ""), None)

    return JsonResponse(data={"status": "201 created"}, status=200, safe=False)


def format_sub_data(data, format="raw"):
        if "con" in data:

            try:
                str = data.split("<con>[")[1].split("]</con>")[0]

            except:
                resp = json.loads(data)
                str = \
                    resp["m2m:sgn"]["m2m:nev"]["m2m:rep"]["m2m:cin"]["con"].split("[")[
                        1].split("]")[0]

            strs = str.split(",")
            if format == "raw":
                return strs
            elif format == "json":
                return strs
            else:
                raise Exception("Unhandled Data Format")
                return strs

